#!/bin/sh

./xmrig -a rx/0 --url "sal.kryptex.network:7028" --user SaLvsCNbjABPoCfjoVjytHf5Jqfd28NTD9kmkYUfSG7D2uzksP1TbNeDZB7ibriXB7D5M3YxfNZ7ER9amRZw25hQBR8kgDrhLRf/MyFirstRig -p x -k