#!/bin/sh

./xmrig -a rx/0 --url "xtm-rx.kryptex.network:7038" --user 12NkgEiiRvsCyKkKmKE2t46fjtZz1i9iZq19QUVs8zkPbEFuuKWzuYLtuohR3t9YEwGPwL8X1S3QZxtT5pt31AYwkAA/MyFirstRig -p x -k